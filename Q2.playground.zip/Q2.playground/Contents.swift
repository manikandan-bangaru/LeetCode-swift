 public class ListNode {
      public var val: Int
      public var next: ListNode?
      public init() { self.val = 0; self.next = nil; }
      public init(_ val: Int) { self.val = val; self.next = nil; }
      public init(_ val: Int, _ next: ListNode?) { self.val = val; self.next = next; }
  }
 
 class Solution {
     func addTwoNumbers( _ l1: ListNode?, _ l2: ListNode?) -> ListNode? {
        let sumNode : ListNode = ListNode()
         var headNode : ListNode? = sumNode
         var c = 0
        var l1c = l1
        var l2c = l2
         while(l1c != nil || l2c != nil || c != 0){
             
             let sum = (l1?.val ?? 0) + (l2?.val ?? 0) + c
             c = (sum >= 10) ? 1 : 0
             let val = sum%10
             headNode?.next = ListNode(val , nil)
             l1c = l1?.next
             l2c = l2?.next
            headNode = headNode?.next
         }
         return sumNode.next
     }
 }
